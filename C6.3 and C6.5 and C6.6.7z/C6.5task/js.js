const status = document.querySelector('#status');

const btn = document.querySelector('.j-btn-test');

let width_window=0;
let height_window=0;

btn.addEventListener('click', () => {


    width_window = window.screen.width;
    height_window = window.screen.height;
    window.alert(`Ширина монитора: ${width_window} px, Высота монитора: ${height_window} px`);

});

