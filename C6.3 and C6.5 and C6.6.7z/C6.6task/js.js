
const wsUri = "wss://echo-ws-service.herokuapp.com";

const output = document.getElementById("output");
const btnOpen = document.querySelector('.j-btn-open');
const btnClose = document.querySelector('.j-btn-close');
const btnSend = document.querySelector('.j-btn-send');

let websocket;



function writeToScreen(message) {
    let pre = document.createElement("p");
    pre.style.wordWrap = "break-word";
    pre.innerHTML = message;
    output.appendChild(pre);
}

btnOpen.addEventListener('click', () => {
    websocket = new WebSocket(wsUri);
    websocket.onopen = function(evt) {
        writeToScreen("CONNECTED");
    };
    websocket.onclose = function(evt) {
        writeToScreen("DISCONNECTED");
    };
    websocket.onmessage = function(evt) {
        writeToScreen(
            '<span style="color: blue;\n' +
            '    display: flex;\n' +
            '    flex-wrap: wrap;\n' +
            '    flex-direction: column;\n' +
            '    align-content: center;\n' +
            '    align-items: center;">Сообщение от сервера: ' + evt.data+'</span>'
        );
    };
    websocket.onerror = function(evt) {
        writeToScreen(
            '<span style="color: red;">ERROR:</span> ' + evt.data
        );
    };
});

btnClose.addEventListener('click', () => {
    websocket.close();
    websocket = null;
});

btnSend.addEventListener('click', () => {
    const message = document.querySelector('input').value;
    // const message = `val${val}`;
    writeToScreen("Сообщение отправителя: " + message);
    websocket.send(message);
});


//-------------------------------------------------------------------------------------------

const status = document.querySelector('#status');
const mapLink = document.querySelector('#map-link');
const btn = document.querySelector('.j-btn-test');

// Функция, выводящая текст об ошибке
const error = () => {
    status.textContent = 'Невозможно получить ваше местоположение';
}

// Функция, срабатывающая при успешном получении геолокации
const success = (position) => {
    console.log('position', position);
    const latitude  = position.coords.latitude;
    const longitude = position.coords.longitude;

    status.textContent = `Широта: ${latitude} °, Долгота: ${longitude} °`;
    status.textContent = '';
    mapLink.href = `https://www.openstreetmap.org/#map=18/${latitude}/${longitude}`;
    mapLink.textContent = 'Гео-локация';
}

btn.addEventListener('click', () => {
    mapLink.href = '';
    mapLink.textContent = '';
    // window.alert("Hello world!");
    if (!navigator.geolocation) {
        status.textContent = 'Geolocation не поддерживается вашим браузером';
    } else {
        status.textContent = 'Определение местоположения…';
        navigator.geolocation.getCurrentPosition(success, error);
    }
});

//--------------------------------------------------------------------------------


